"""
Market Sentiment Engine
Fetches NIFTY 50 and INDIA VIX data to determine the market's "Mood" (Fear vs Greed).
"""

import yfinance as yf
import traceback

class MarketSentiment:
    def __init__(self):
        self.nifty_ticker = "^NSEI"
        self.vix_ticker = "^INDIAVIX"
        self.status = "NEUTRAL"
        self.score = 50  # 0 (Extreme Fear) to 100 (Extreme Greed)
        self.details = "Initializing..."

    def fetch_sentiment(self):
        """
        Fetches live data and calculates sentiment score.
        Logic:
        - VIX High (> 15) + Rising = Fear
        - NIFTY Dropping (> 1%) = Fear
        - NIFTY Rising + VIX Stable = Greed
        """
        try:
            # Suppress yfinance warnings/errors when market is closed
            import warnings
            warnings.filterwarnings("ignore")
            
            # Fetch Data (1 day period to get today's change)
            # Fetch Data (1 day period to get today's change)
            # NOTE: Disabling live fetch for now to prevent "^INDIAVIX possibly delisted" errors spamming logs.
            # We will default to a NEUTRAL stance until a better data source is available.
            return {
                "score": 50, "status": "NEUTRAL 😐", 
                "details": "Market data disabled (using safe defaults).",
                "nifty_change": 0.0, "vix_change": 0.0
            }

            """
            try:
                tickers = yf.Tickers(f"{self.nifty_ticker} {self.vix_ticker}")
                # ... (rest of old logic commented out)
            """

            # Calculate Changes
            nifty_change = ((nifty_info['Close'].iloc[-1] - nifty_info['Close'].iloc[0]) / nifty_info['Close'].iloc[0]) * 100
            vix_current = vix_info['Close'].iloc[-1]
            vix_change = ((vix_info['Close'].iloc[-1] - vix_info['Close'].iloc[0]) / vix_info['Close'].iloc[0]) * 100

            # --- LOGIC ENGINE ---
            
            # Base Score: 50 (Neutral)
            score = 50
            reason = []

            # 1. VIX Impact (Fear Gauge)
            if vix_current > 20: 
                score -= 20
                reason.append(f"High VIX ({vix_current:.1f})")
            elif vix_current < 12:
                score += 10
                reason.append("Low Volatility")

            if vix_change > 5:
                score -= 15
                reason.append(f"VIX Spiking (+{vix_change:.1f}%)")
            
            # 2. Market Trend (Nifty)
            if nifty_change > 1.0:
                score += 20
                reason.append(f"Nifty Rally (+{nifty_change:.1f}%)")
            elif nifty_change < -1.0:
                score -= 20
                reason.append(f"Nifty Drop ({nifty_change:.1f}%)")
            
            # Clamp Score 0-100
            self.score = max(0, min(100, score))

            # Determine Text Status
            if self.score <= 30: self.status = "EXTREME FEAR 😱"
            elif self.score <= 45: self.status = "FEAR 😨"
            elif self.score <= 55: self.status = "NEUTRAL 😐"
            elif self.score <= 70: self.status = "GREED 🤑"
            else: self.status = "EXTREME GREED 🚀"

            # -- AI REASONING ENGINE --
            ai_reasoning = ""
            if self.score < 30:
                ai_reasoning = "Markets are in panic mode. High volatility suggests aggressive selling pressure."
            elif self.score > 70:
                ai_reasoning = "Euphoria is driving prices up. Caution advised as reversals can be sudden."
            elif vix_change > 5:
                ai_reasoning = "Rising fear index indicates traders are hedging against potential downside."
            else:
                ai_reasoning = "Market sentiment is balanced. Traders are awaiting new catalysts."
                
            self.details = f"{', '.join(reason)}. {ai_reasoning}" if reason else f"Market is stable. {ai_reasoning}"
            
            return {
                "score": self.score,
                "status": self.status,
                "details": self.details,
                "nifty_change": nifty_change,
                "vix_change": vix_change
            }

        except Exception as e:
            # Fallback / Simulation Mode
            import random
            
            # Random Walk the score if we can't fetch real data
            # Simulating a "nervous" market
            self.score = max(0, min(100, self.score + random.randint(-5, 5)))
            
            if self.score <= 30: self.status = "EXTREME FEAR 😱"
            elif self.score <= 45: self.status = "FEAR 😨"
            elif self.score <= 55: self.status = "NEUTRAL 😐"
            elif self.score <= 70: self.status = "GREED 🤑"
            else: self.status = "EXTREME GREED 🚀"
            
            mock_reason = "Simulated Market Data active."
            if self.score < 40: mock_reason = "Simulation: Bears are dominating the trend."
            elif self.score > 60: mock_reason = "Simulation: Bulls are pushing indices higher."
            
            return {
                "score": self.score,
                "status": self.status,
                "details": mock_reason,
                "nifty_change": 0.0,
                "vix_change": 0.0
            }

# Usage
if __name__ == "__main__":
    ms = MarketSentiment()
    print(ms.fetch_sentiment())
