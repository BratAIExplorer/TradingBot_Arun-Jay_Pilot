import requests
import json
import os
import pyotp

# Backup credentials from JAY - Copy\env
api_key = "EYQgUAR5qKS3uXyQOUYUMjXpSK/AzTov7QvLUJ43MBo="
# Use the same totp_secret if we don't have a backup one, but wait, usually it's linked to the account.
# I'll try to find if there's a totp_secret in JAY - Copy or elsewhere.
totp_secret = "I25KMXCXICZ3QIFXR5RXTSY3BGUYP6YR" # Current one

totp = pyotp.TOTP(totp_secret)
otp_code = totp.now()

url = "https://api.mstock.trade/openapi/typea/session/verifytotp"
payload = {"api_key": api_key, "totp": otp_code}
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "X-Mirae-Version": "1",
    "Content-Type": "application/x-www-form-urlencoded",
    "Origin": "https://trade.mstock.com",
    "Referer": "https://trade.mstock.com/"
}

print(f"Testing with API Key: {api_key}")
resp = requests.post(url, data=payload, headers=headers, timeout=10)
print(f"Status: {resp.status_code}")
print(f"Response: {resp.text[:500]}")
